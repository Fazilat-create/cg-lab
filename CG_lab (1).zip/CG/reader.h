// Функции чтения матрицы и вектора из файлов (файл преподавателя).
//
// Изменения относительно исходной версии:
//  - имя файла теперь строится для любого n: <filepath>/m_<n>.dat и
//    <filepath>/v_<n>.dat (раньше поддерживались только 1024, 2048, 4096,
//    8192, а для остальных размеров открывался "default.dat", поэтому n = 12
//    прочитать было нельзя);
//  - добавлена проверка открытия файла вектора;
//  - удалены неиспользуемые варианты read_vector_vec / read_matrix_vec
//    (_mm_malloc, нужны были только для компилятора Intel);
//  - добавлены нужные #include, чтобы заголовок не зависел от порядка
//    подключения в .cpp.
//
// Формат файлов: числа через пробел, матрица записана по строкам.

#ifndef READER_H
#define READER_H

#include <cstdio>
#include <cstdlib>
#include <fstream>

inline double* read_vector(int n, const char* filepath)
{
    double* b = static_cast<double *>(malloc(n * sizeof(double)));
    char filename[300];
    sprintf(filename, "%s/v_%d.dat", filepath, n);
    std::ifstream f;
    f.open(filename);

    if (!f.is_open())
    {
        printf("vector file %s not found.\n", filename);
        free(b);
        return NULL;
    }

    for (int i = 0; i < n; ++i)
    {
        f >> b[i];
    }

    if (f.fail())
    {
        printf("error: file %s contains less than %d numbers.\n", filename, n);
    }

    f.close();

    return b;
}

inline double** read_matrix(int n, const char* filepath)
{
    char filename[300];
    sprintf(filename, "%s/m_%d.dat", filepath, n);
    std::ifstream f;
    f.open(filename);

    if (!f.is_open())
    {
        printf("matrix file %s not found.\n", filename);
        return NULL;
    }

    double** a = static_cast<double **>(malloc(n * sizeof(double *)));
    for (int i = 0; i < n; ++i)
    {
        a[i] = static_cast<double *>(malloc(n * sizeof(double)));
    }

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            f >> a[i][j];
        }
    }

    if (f.fail())
    {
        printf("error: file %s contains less than %d*%d numbers.\n", filename, n, n);
    }

    f.close();

    return a;
}

#endif
