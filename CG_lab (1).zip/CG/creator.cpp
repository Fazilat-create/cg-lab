// Генератор данных (файл преподавателя, адаптирован для Linux / Google Colab).
//
// Создаёт симметричную матрицу A с диагональным преобладанием
// (=> симметричная положительно определённая) и вектор правой части
// b = A * (1, 1, ..., 1). Значит, точное решение системы Ax = b — вектор
// из одних единиц, по нему удобно проверять программы.
//
// Запуск:
//   ./bin/creator n [data_dir] [p]
//     n        - размер матрицы (например 12, 1024, 2048, 4096, 8192)
//     data_dir - папка для файлов (по умолчанию ./data)
//     p        - необязательно: дополнительно разрезать матрицу и вектор на
//                p частей по строкам (функции division_* преподавателя).
//                Файлы частей пишутся в data_dir/<n>_<p>/matrix/k.dat и
//                data_dir/<n>_<p>/vector/k.dat. MPI-программа этими файлами
//                НЕ пользуется: в ней процесс 0 сам читает общую матрицу
//                и раздаёт строки остальным процессам.
//
// Результат: data_dir/m_<n>.dat и data_dir/v_<n>.dat — именно эти имена ищет
// reader.h.
//
// Изменения относительно исходной версии:
//  - убраны Windows-функции (GetTickCount, mkdir с одним аргументом);
//  - srand(SEED) с постоянным SEED: данные воспроизводимы;
//  - случайное число округляется до 6 знаков после запятой, а файлы пишутся
//    с точностью 10 значащих цифр. Поэтому в файл попадают ровно те же числа,
//    что были в памяти, и b = A * (1,...,1) выполняется точно;
//  - функции чтения убраны (они есть в reader.h), имена файлов совпадают
//    с reader.h, размер и папка задаются аргументами командной строки;
//  - добавлена проверка диагонального преобладания.

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <sys/stat.h>   // mkdir в Linux

using namespace std;

const int SEED = 1;     // постоянное начальное значение генератора

long double **generate_matrix(int size){
	long double **matrix = new long double *[size];
	for(int i = 0; i < size; i++){
		matrix[i] = new long double [size];
	}
	srand(SEED);

	for (int i = 0; i < size; i++) {
		for(int j = i; j < size; j++){
			double random = ((double) rand() / RAND_MAX);
			random = floor(random * 1e6 + 0.5) / 1e6;   // 6 знаков после запятой
			if(i != j){
				matrix[i][j] = -random;
				matrix[j][i] = -random;
			} else {
				matrix[i][j] = (random + 0.5) * 10000;
			}
		}
	}
	return matrix;
}

long double *generate_vector(long double **matrix, int size){
	long double *vector = new long double [size];

	for(int i = 0; i < size; i++){
		long double sum = 0;
		for(int j = 0; j < size; j++){
			sum += matrix[i][j];
		}
		vector[i] = sum;
	}
	return vector;
}

// Проверка: |a_ii| > сумма |a_ij| (j != i) для каждой строки.
// Симметричная матрица с таким свойством и положительной диагональю
// положительно определена.
bool is_diagonally_dominant(long double **matrix, int size){
	for(int i = 0; i < size; i++){
		long double sum = 0;
		for(int j = 0; j < size; j++){
			if(j != i){
				sum += fabsl(matrix[i][j]);
			}
		}
		if(matrix[i][i] <= sum){
			return false;
		}
	}
	return true;
}

void out_matrix(string file_path, string filename, long double **matrix, int size){
	ofstream fout;

	fout.open(file_path + filename);
	fout.precision(10);

	for (int i = 0; i < size; i++) {
		for(int j = 0; j < size; j++){
			fout << matrix[i][j] << " ";
		}
		fout << "\n";
	}

	fout.close();
}

void out_vector(string file_path, string filename, long double *vector, int size){
	ofstream fout;

	fout.open(file_path + filename);
	fout.precision(17);

	for (int i = 0; i < size; i++) {
		fout << vector[i] << " ";
	}
	fout << "\n";

	fout.close();
}

void division_matrix(string file_path, long double **matrix, int matrix_size, int division_number){
	ofstream fout;
	int div = matrix_size / division_number;

	for(int k = 0; k < division_number; k++){
		fout.open(file_path + to_string(k) + ".dat");
		fout.precision(10);
		for (int i = 0; i < div; i++) {
			for(int j = 0; j < matrix_size; j++){
				fout << matrix[i + div * k][j] << " ";
			}
			fout << "\n";
		}
		fout.close();
	}
}

void division_vector(string file_path, long double *vector, int vector_size, int division_number){
	ofstream fout;
	int div = vector_size / division_number;
	for(int k = 0; k < division_number; k++){
		fout.open(file_path + to_string(k) + ".dat");
		fout.precision(17);
		for (int i = 0; i < div; i++) {
			fout << vector[i + div * k] << " ";
		}
		fout.close();
	}
}

void print_vector(long double *vector, int size){
	for(int i = 0; i < size; i++){
		cout << vector[i] << " ";
	}
	cout << endl;
}

void print(long double **matrix, long double *vector, int size){
	cout.precision(10);   // как в файлах
	cout << "--------------matrix--------------" << endl;
	for(int i = 0; i < size; i++){
		print_vector(matrix[i], size);
	}
	cout << "--------------vector--------------" << endl;
	print_vector(vector, size);
}

int divide(string filepath, long double **matrix, long double *vector, int size, int dividers_number){
	if(size % dividers_number != 0){
		return -1;
	}

	string dir = filepath + to_string(size) + "_" + to_string(dividers_number);
	mkdir(dir.c_str(), 0755);
	string dir_matrix = dir + "/matrix/";
	string dir_vector = dir + "/vector/";
	mkdir(dir_matrix.c_str(), 0755);
	mkdir(dir_vector.c_str(), 0755);

	division_vector(dir_vector, vector, size, dividers_number);
	division_matrix(dir_matrix, matrix, size, dividers_number);
	cout << "Parts for " << dividers_number << " processes: " << dir << "/" << endl;
	return 0;
}

int main(int argc, char** argv){
	if(argc < 2){
		cout << "usage: " << argv[0] << " n [data_dir] [p]" << endl;
		return 1;
	}
	int size = atoi(argv[1]);
	string filepath = "./data";
	if(argc > 2){
		filepath = argv[2];
	}
	int dividers_number = 1;
	if(argc > 3){
		dividers_number = atoi(argv[3]);
	}
	filepath += "/";
	mkdir(filepath.c_str(), 0755);   // создать папку, если её нет

	long double **matrix;
	long double *vector;

	string filename_matrix = "m_" + to_string(size) + ".dat";
	string filename_vector = "v_" + to_string(size) + ".dat";

	//generate
	matrix = generate_matrix(size);
	vector = generate_vector(matrix, size);

	if(is_diagonally_dominant(matrix, size)){
		cout << "Matrix " << size << "x" << size
			<< ": symmetric, diagonally dominant => positive definite" << endl;
	} else {
		cout << "WARNING: matrix is not diagonally dominant!" << endl;
	}

	//write to file
	out_matrix(filepath, filename_matrix, matrix, size);
	out_vector(filepath, filename_vector, vector, size);
	cout << "Written: " << filepath + filename_matrix << ", "
		<< filepath + filename_vector << endl;

	//divide to directions (only if p > 1 was given)
	if(dividers_number > 1){
		if(divide(filepath, matrix, vector, size, dividers_number) == -1){
			cout << "can't split! size(" << size << ") % dividers_number(" << dividers_number
				<< ") = " << size % dividers_number << endl;
			return -2;
		}
	}

	//print to console (only small matrices)
	if(size <= 12){
		print(matrix, vector, size);
	}

	for(int i = 0; i < size; i++) {
		delete[] matrix[i];
	}
	delete[] vector;
	delete[] matrix;

	return 0;
}
