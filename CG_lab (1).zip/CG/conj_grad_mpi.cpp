// Параллельное (MPI) решение СЛАУ Ax = b методом сопряжённых градиентов.
// Построено на основе последовательной программы conj_grad.cpp:
// шаги алгоритма и имена переменных те же, комментарии "1. Set x0" и т.д.
// совпадают с последовательной версией.
//
// Компиляция (размер матрицы задаётся при компиляции, как в conj_grad.cpp):
//   mpic++ -O2 -DSIZE=12 conj_grad_mpi.cpp -o bin/conj_grad_mpi_12
// Запуск:
//   mpirun --allow-run-as-root --oversubscribe -np 4 ./bin/conj_grad_mpi_12 ./data
//
// Схема распараллеливания:
//  - процесс 0 читает всю матрицу A и вектор b;
//  - вектор b целиком рассылается всем процессам (MPI_Bcast);
//  - матрица делится по строкам: процесс с номером rank получает строки
//    first ... first + n_loc - 1, где n_loc = SIZE / nproc, first = rank * n_loc
//    (рассылка обычными MPI_Send / MPI_Recv, по одной строке);
//  - каждый процесс хранит свои n_loc элементов векторов x, r, tmp,
//    а вектор направления h — целиком (он нужен для умножения A*h);
//  - скалярные произведения: локальная сумма + MPI_Allreduce(MPI_SUM);
//  - норма разности ||x_n - x||: локальный максимум + MPI_Allreduce(MPI_MAX);
//  - новый вектор h собирается у всех процессов через MPI_Allgather;
//  - в конце полный вектор x собирается на процессе 0 (MPI_Gather)
//    и проверяется.
//
// Измерение времени (по требованиям преподавателя):
//  - чтение файлов, выделение памяти и рассылка данных — ДО замера;
//  - перед замером одна синхронизация MPI_Barrier;
//  - каждый процесс меряет своё время (MPI_Wtime);
//  - итоговое время = максимум по процессам (MPI_Reduce с MPI_MAX);
//  - внутри цикла нет MPI_Barrier.

#include <mpi.h>
#include <cstdio>
#include <fstream>
#include <cmath>
#include <iostream>
#include <string.h>
#include <stdlib.h>

#include "reader.h"

#ifndef SIZE
#define SIZE 1024
#endif

double dot_product(double* b1, double* b2, int n);

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv);

    int rank, nproc;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nproc);

    if (argc < 2)
    {
        if (rank == 0) printf("usage: %s data_dir\n", argv[0]);
        MPI_Finalize();
        return 1;
    }
    char filepath[256];
    strcpy(filepath, argv[1]);

    // Каждый процесс получает одинаковое число строк, поэтому SIZE должен
    // делиться на число процессов (для всех размеров из задания это так).
    if (SIZE % nproc != 0)
    {
        if (rank == 0) printf("SIZE (%d) must be divisible by number of processes (%d)\n", SIZE, nproc);
        MPI_Finalize();
        return 1;
    }
    int n_loc = SIZE / nproc;     // сколько строк у каждого процесса
    int first = rank * n_loc;     // номер первой "своей" строки

    FILE *time;
    char file_time[40];

    if (rank == 0)
    {
        printf("Matrix size: %d*%d, processes: %d, rows per process: %d\n", SIZE, SIZE, nproc, n_loc);
    }

    double alpha, beta, d1, d2, diff;

    // ---------- Чтение данных (только процесс 0) ----------
    double** a = NULL;     // вся матрица (есть только у процесса 0)
    double* b = NULL;      // весь вектор b (будет у всех процессов)
    int ok = 1;
    if (rank == 0)
    {
        a = read_matrix(SIZE, filepath);
        b = read_vector(SIZE, filepath);
        if (a == NULL || b == NULL) ok = 0;
    }
    MPI_Bcast(&ok, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if (!ok)
    {
        MPI_Finalize();
        return 1;
    }

    // ---------- Рассылка вектора b всем процессам ----------
    if (rank != 0)
    {
        b = static_cast<double*>(malloc(SIZE * sizeof(double)));
    }
    MPI_Bcast(b, SIZE, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    // ---------- Рассылка строк матрицы ----------
    // a_loc[i] - это строка номер (first + i) матрицы A
    double** a_loc = static_cast<double**>(malloc(n_loc * sizeof(double*)));
    for (int i = 0; i < n_loc; ++i)
    {
        a_loc[i] = static_cast<double*>(malloc(SIZE * sizeof(double)));
    }
    if (rank == 0)
    {
        for (int i = 0; i < n_loc; ++i)                  // свои строки - просто копируем
        {
            memcpy(a_loc[i], a[i], SIZE * sizeof(double));
        }
        for (int p = 1; p < nproc; ++p)                  // остальным - отправляем
        {
            for (int i = 0; i < n_loc; ++i)
            {
                MPI_Send(a[p * n_loc + i], SIZE, MPI_DOUBLE, p, i, MPI_COMM_WORLD);
            }
        }
    }
    else
    {
        for (int i = 0; i < n_loc; ++i)
        {
            MPI_Recv(a_loc[i], SIZE, MPI_DOUBLE, 0, i, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
    }

    // ---------- Выделение памяти под векторы ----------
    // Локальные части (n_loc элементов): x, x_n, r, r_n, h_n, tmp
    // Полные векторы (SIZE элементов):   h (направление), x_all (весь x)
    double* x = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* x_n = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* r = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* r_n = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* h_n = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* tmp = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* h = static_cast<double*>(malloc(SIZE * sizeof(double)));
    double* x_all = static_cast<double*>(malloc(SIZE * sizeof(double)));

    double d_loc;      // локальная часть скалярного произведения
    double norm_loc;   // локальный максимум |x_n - x|

    // ---------- Начало замера времени ----------
    MPI_Barrier(MPI_COMM_WORLD);   // единственная синхронизация перед замером
    double t_start = MPI_Wtime();

    // 1. Set x0 (свои элементы), затем собираем весь x0 у всех процессов
    for (int i = 0; i < n_loc; ++i)
    {
        x[i] = b[first + i] / a_loc[i][first + i];
    }
    MPI_Allgather(x, n_loc, MPI_DOUBLE, x_all, n_loc, MPI_DOUBLE, MPI_COMM_WORLD);

    // 2. Calculate residual vector r0 = b - A * x0 (свои строки)
    for (int i = 0; i < n_loc; ++i)
    {
        tmp[i] = 0.0;
        for (int j = 0; j < SIZE; ++j)
        {
            tmp[i] += a_loc[i][j] * x_all[j];
        }
        r[i] = b[first + i] - tmp[i];
    }

    // 3. Calculate direction vector h0 = r0 (собираем полный h у всех)
    MPI_Allgather(r, n_loc, MPI_DOUBLE, h, n_loc, MPI_DOUBLE, MPI_COMM_WORLD);

    double norm;
    int it = 0;
    do
    {
        it++;

        //1 Calculate alpha
        d_loc = dot_product(r, r, n_loc);
        MPI_Allreduce(&d_loc, &d1, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

        for (int i = 0; i < n_loc; ++i)      // tmp = A * h, только свои строки
        {
            tmp[i] = 0.0;
            for (int j = 0; j < SIZE; ++j)
            {
                tmp[i] += a_loc[i][j] * h[j];
            }
        }

        d_loc = dot_product(tmp, h + first, n_loc);   // h + first - "своя" часть h
        MPI_Allreduce(&d_loc, &d2, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
        alpha = d1 / d2;

        //2 Calculate r_n
        for (int i = 0; i < n_loc; ++i)
        {
            r_n[i] = r[i] - alpha * tmp[i];
        }

        //3 Calculate beta
        d_loc = dot_product(r_n, r_n, n_loc);
        MPI_Allreduce(&d_loc, &d2, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
        beta = d2 / d1;

        //4 Calculate h_n and x_n
        for (int i = 0; i < n_loc; ++i)
        {
            h_n[i] = r_n[i] + beta * h[first + i];
            x_n[i] = x[i] + alpha * h[first + i];
        }

        norm_loc = 0.0;
        for (int i = 0; i < n_loc; ++i)
        {
            diff = fabs(x_n[i] - x[i]);
            if (diff > norm_loc)
            {
                norm_loc = diff;
            }
            x[i] = x_n[i];
            r[i] = r_n[i];
        }
        MPI_Allreduce(&norm_loc, &norm, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);

        // h = h_n: собираем новый полный вектор направления у всех процессов
        MPI_Allgather(h_n, n_loc, MPI_DOUBLE, h, n_loc, MPI_DOUBLE, MPI_COMM_WORLD);
    } while (norm > 1e-8 && it < 10000);

    // ---------- Конец замера времени ----------
    double elapsed = MPI_Wtime() - t_start;    // локальное время процесса
    double max_time;                           // максимум по всем процессам
    MPI_Reduce(&elapsed, &max_time, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    // Сбор полного решения на процессе 0 (после замера: в последовательной
    // программе такого шага нет, это только для проверки результата)
    MPI_Gather(x, n_loc, MPI_DOUBLE, x_all, n_loc, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        // Файл преподавателя out/time_<n>.dat: 1-й столбец - число процессов
        sprintf(file_time, "./out/time_%d.dat", SIZE);
        if ((time = fopen(file_time, "a")) == NULL) {
            printf("Error at opening of the file.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        fprintf(time, "%d\t%.12le\t%d\t%.12le\n", nproc, max_time, it, norm);
        fclose(time);

        printf("Number of iterations(K): %d\n", it);
        printf("Total time: %10.8f s\n", max_time);

        // Проверка решения по полной матрице (она есть у процесса 0)
        double res_max = 0.0, err_max = 0.0;
        for (int i = 0; i < SIZE; ++i)
        {
            double s = 0.0;
            for (int j = 0; j < SIZE; ++j)
            {
                s += a[i][j] * x_all[j];
            }
            if (fabs(s - b[i]) > res_max) res_max = fabs(s - b[i]);
            if (fabs(x_all[i] - 1.0) > err_max) err_max = fabs(x_all[i] - 1.0);
        }
        printf("Residual max|Ax-b|: %.3e\n", res_max);
        printf("Error max|x-1|: %.3e\n", err_max);
        if (SIZE <= 12)
        {
            printf("x =");
            for (int i = 0; i < SIZE; ++i) printf(" %.12f", x_all[i]);
            printf("\n");
        }

        // Решение в файл out/x_<n>_np<p>.dat (для сравнения с последовательной)
        char file_x[64];
        sprintf(file_x, "./out/x_%d_np%d.dat", SIZE, nproc);
        FILE *fx = fopen(file_x, "w");
        if (fx != NULL)
        {
            for (int i = 0; i < SIZE; ++i) fprintf(fx, "%.15e\n", x_all[i]);
            fclose(fx);
        }

        // Строка в общую таблицу результатов out/results.csv
        // столбцы: n, p, time_s, iterations, norm, residual
        FILE *fcsv = fopen("./out/results.csv", "a");
        if (fcsv != NULL)
        {
            fprintf(fcsv, "%d,%d,%.9f,%d,%.6e,%.6e\n", SIZE, nproc, max_time, it, norm, res_max);
            fclose(fcsv);
        }

        for (int i = 0; i < SIZE; ++i)
        {
            free(a[i]);
        }
        free(a);
    }

    for (int i = 0; i < n_loc; ++i)
    {
        free(a_loc[i]);
    }
    free(a_loc);
    free(b);
    free(x);
    free(x_n);
    free(r);
    free(r_n);
    free(h_n);
    free(tmp);
    free(h);
    free(x_all);

    MPI_Finalize();
    return 0;
}

double dot_product(double* b1, double* b2, int n)
{
    double res = 0.0;
    for (int i = 0; i < n; ++i)
    {
        res += b1[i] * b2[i];
    }
    return res;
}
