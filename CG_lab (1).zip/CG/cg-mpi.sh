#!/bin/bash
# MPI-программа: компиляция и запуск для разных размеров и чисел процессов.
#
# Использование:
#   bash cg-mpi.sh "размеры" "числа процессов"
#   bash cg-mpi.sh "12" "2 3 4"                 # пункт 4 задания
#   bash cg-mpi.sh                              # 1024 2048 4096 8192 x 2 4 8 16 32
#   RUNS=3 bash cg-mpi.sh "1024 2048" "2 4"     # каждый запуск повторить 3 раза
#
# Результаты: out/time_<n>.dat (1-й столбец - число процессов) и out/results.csv

PROGRAM_NAME=conj_grad_mpi
PROGRAM_PATH=./bin
DATA_PATH=./data
SIZES=${1:-"1024 2048 4096 8192"}
PROCS=${2:-"2 4 8 16 32"}
RUNS=${RUNS:-1}

mkdir -p $PROGRAM_PATH out

for n in $SIZES
do
	mpic++ -O2 $PROGRAM_NAME.cpp -DSIZE=$n -o $PROGRAM_PATH/$PROGRAM_NAME'_'$n
done

for n in $SIZES
do
	for p in $PROCS
	do
		for ((r=1; r<=RUNS; r++))
		do
			echo 'Run '$PROGRAM_NAME'_'$n' on '$p' processes'
			mpirun --allow-run-as-root --oversubscribe -np $p $PROGRAM_PATH/$PROGRAM_NAME'_'$n $DATA_PATH
		done
	done
done
