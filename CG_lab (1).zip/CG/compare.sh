#!/bin/bash
# Сравнение решений последовательной и MPI-программы.
# Использование: bash compare.sh 12
# Сравнивает out/x_<n>_seq.dat с каждым файлом out/x_<n>_np<p>.dat и
# печатает максимальную разность max|x_seq - x_mpi|.

n=$1
if [ ! -f out/x_${n}_seq.dat ]; then
	echo "out/x_${n}_seq.dat not found: run the sequential program for n=$n first"
	exit 1
fi

for f in out/x_${n}_np*.dat
do
	if [ ! -f "$f" ]; then
		echo "no MPI results for n=$n"
		exit 1
	fi
	paste out/x_${n}_seq.dat $f | awk -v f=$f '{d = $1 - $2; if (d < 0) d = -d; if (d > m) m = d}
		END {printf "%s: max|x_seq - x_mpi| = %.3e\n", f, m}'
done
