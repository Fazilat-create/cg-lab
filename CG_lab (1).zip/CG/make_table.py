# Построение таблицы Excel с временем, ускорением и эффективностью.
#
#   python3 make_table.py             -> out/results.xlsx  (по данным out/results.csv)
#   python3 make_table.py --template  -> results_template.xlsx (пустой шаблон)
#
# out/results.csv дописывают программы conj_grad и conj_grad_mpi, по строке
# на каждый запуск: n, p, time_s, iterations, norm, residual
# (p = 0 означает последовательную программу).
# Если один и тот же запуск (n, p) повторялся несколько раз, в таблицу
# попадает среднее время.
#
# Формулы:  S = Tпосл / Tпаралл,   E = S / p
# В файле это настоящие формулы Excel: если поменять время в жёлтой ячейке,
# ускорение и эффективность пересчитаются.

import csv
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.chart import LineChart, Reference
from openpyxl.utils import get_column_letter

FONT = "Arial"
YELLOW = PatternFill("solid", start_color="FFFF00")
GREY = PatternFill("solid", start_color="D9D9D9")


def read_csv(path):
    """Возвращает словари: время[(n, p)] = среднее, итерации[(n, p)], и все строки."""
    rows = []
    with open(path) as f:
        for line in csv.reader(f):
            if len(line) >= 4:
                rows.append([int(line[0]), int(line[1]), float(line[2]), int(line[3])] + line[4:])
    times = {}
    iters = {}
    for n, p, t, it, *rest in rows:
        times.setdefault((n, p), []).append(t)
        iters[(n, p)] = it
    avg = {key: sum(v) / len(v) for key, v in times.items()}
    return avg, iters, rows


def cell(ws, ref, value, bold=False, fill=None, fmt=None):
    c = ws[ref]
    c.value = value
    c.font = Font(name=FONT, bold=bold)
    c.alignment = Alignment(horizontal="center")
    if fill:
        c.fill = fill
    if fmt:
        c.number_format = fmt
    return c


def build(sizes, procs, times, iters):
    wb = Workbook()
    ws = wb.active
    ws.title = "Results"
    last = get_column_letter(2 + len(procs))   # последняя колонка таблиц
    k = len(sizes)

    ws["A1"] = "Метод сопряжённых градиентов, MPI: ускорение и эффективность"
    ws["A1"].font = Font(name=FONT, bold=True, size=13)
    ws["A2"] = ("Жёлтые ячейки — исходные данные (время в секундах, например 1.743). "
                "Остальное считается формулами: S = Tпосл / Tпаралл, E = S / p.")
    ws["A2"].font = Font(name=FONT, italic=True)

    # Начальные строки четырёх таблиц
    r_time = 4
    r_s = r_time + k + 2
    r_e = r_s + k + 2
    r_it = r_e + k + 2

    def header(row, title, first_col_title):
        cell(ws, f"A{row - 1}", title, bold=True).alignment = Alignment(horizontal="left")
        cell(ws, f"A{row}", "n", bold=True, fill=GREY)
        cell(ws, f"B{row}", first_col_title, bold=True, fill=GREY, fmt='"p="0')
        for j, p in enumerate(procs):
            # число процессов хранится как число, показывается как "p=4"
            cell(ws, f"{get_column_letter(3 + j)}{row}", p, bold=True, fill=GREY, fmt='"p="0')

    header(r_time + 1, "Время решения, с", "Tпосл")
    # в таблицах S и E столбец B - последовательная программа (p = 1, S = 1, E = 1)
    header(r_s + 1, "Ускорение S = Tпосл / Tпаралл", 1)
    header(r_e + 1, "Эффективность E = S / p", 1)
    header(r_it + 1, "Число итераций", "посл.")

    for i, n in enumerate(sizes):
        rt = r_time + 2 + i       # строка в таблице времени
        rs = r_s + 2 + i          # строка в таблице ускорения
        re = r_e + 2 + i          # строка в таблице эффективности
        ri = r_it + 2 + i         # строка в таблице итераций
        for row in (rt, rs, re, ri):
            cell(ws, f"A{row}", n, bold=True)
        cell(ws, f"B{rt}", times.get((n, 0)), fill=YELLOW, fmt="0.000000")
        cell(ws, f"B{ri}", iters.get((n, 0)), fill=YELLOW, fmt="0")
        for j, p in enumerate(procs):
            col = get_column_letter(3 + j)
            cell(ws, f"{col}{rt}", times.get((n, p)), fill=YELLOW, fmt="0.000000")
            cell(ws, f"{col}{ri}", iters.get((n, p)), fill=YELLOW, fmt="0")
        for j in range(len(procs) + 1):          # столбцы B, C, D, ...
            col = get_column_letter(2 + j)
            hdr = f"{col}${r_s + 1}"   # ячейка с числом p в заголовке
            cell(ws, f"{col}{rs}", f'=IF(OR($B{rt}="",{col}{rt}=""),"",$B{rt}/{col}{rt})', fmt="0.000")
            cell(ws, f"{col}{re}", f'=IF({col}{rs}="","",{col}{rs}/{hdr})', fmt="0.000")

    ws.column_dimensions["A"].width = 10
    for j in range(len(procs) + 1):
        ws.column_dimensions[get_column_letter(2 + j)].width = 13

    # График ускорения S(p) для каждого n
    chart = LineChart()
    chart.title = "Ускорение S(p)"
    chart.x_axis.title = "число процессов p"
    chart.y_axis.title = "S"
    chart.height, chart.width = 8, 16
    data = Reference(ws, min_col=1, max_col=2 + len(procs), min_row=r_s + 2, max_row=r_s + 1 + k)
    chart.add_data(data, from_rows=True, titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=2, max_col=2 + len(procs), min_row=r_s + 1))
    for s in chart.series:
        s.smooth = False
        s.marker.symbol = "circle"
    chart.y_axis.scaling.min = 0
    chart.legend.position = "b"
    ws.add_chart(chart, f"{get_column_letter(4 + len(procs))}4")

    wb.calculation.fullCalcOnLoad = True   # Excel пересчитает формулы при открытии
    return wb


def main():
    procs_default = [2, 4, 8, 16, 32]
    sizes_default = [1024, 2048, 4096, 8192]

    if "--template" in sys.argv:
        wb = build(sizes_default, procs_default, {}, {})
        wb.save("results_template.xlsx")
        print("written results_template.xlsx")
        return

    times, iters, rows = read_csv("out/results.csv")
    # Лист Results - только исследование из задания (n = 1024..8192, p = 2..32);
    # все запуски (в том числе n = 12 на 2, 3, 4 процессах) - на листе "All runs".
    sizes = [n for n in sizes_default if any(key[0] == n for key in times)]
    if not sizes:
        sizes = sorted({n for n, p in times})
    procs = procs_default
    wb = build(sizes, procs, times, iters)

    # Второй лист: все запуски как есть
    raw = wb.create_sheet("All runs")
    raw.append(["n", "p (0 = посл.)", "time, s", "iterations", "norm", "residual"])
    for c in raw[1]:
        c.font = Font(name=FONT, bold=True)
    for r in rows:
        raw.append([r[0], r[1], r[2], r[3]] + [float(v) for v in r[4:6]])
    for row in raw.iter_rows(min_row=2):
        for c in row:
            c.font = Font(name=FONT)

    wb.save("out/results.xlsx")
    print("written out/results.xlsx")


main()
