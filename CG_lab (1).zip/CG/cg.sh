#!/bin/bash
# Последовательная программа: компиляция и запуск (скрипт преподавателя,
# адаптирован для Google Colab: g++ вместо icpc, запуск без mpirun).
#
# Использование:
#   bash cg.sh                      # размеры 1024 2048 4096 8192
#   bash cg.sh 12                   # только n = 12
#   RUNS=3 bash cg.sh 1024 2048     # каждый запуск повторить 3 раза
#
# Результаты: out/time_<n>.dat (формат преподавателя) и out/results.csv

PROGRAM_NAME=conj_grad
PROGRAM_PATH=./bin
DATA_PATH=./data
SIZES=${@:-"1024 2048 4096 8192"}
RUNS=${RUNS:-1}

mkdir -p $PROGRAM_PATH out

for n in $SIZES
do
	g++ -O2 $PROGRAM_NAME.cpp -DSIZE=$n -o $PROGRAM_PATH/$PROGRAM_NAME'_'$n
done

for n in $SIZES
do
	for ((r=1; r<=RUNS; r++))
	do
		echo 'Run '$PROGRAM_NAME'_'$n
		$PROGRAM_PATH/$PROGRAM_NAME'_'$n $DATA_PATH
	done
done
