// Генератор данных: симметричная матрица A с диагональным преобладанием
// и вектор b = A * (1, 1, ..., 1). Точное решение системы Ax = b - все единицы.
//
// Запуск: ./bin/creator n [p]
//   n - размер матрицы; файлы: data/m_<n>.dat и data/v_<n>.dat
//   p - необязательно: ещё разрезать данные на p частей по строкам
//       (data/<n>_<p>/matrix/k.dat, data/<n>_<p>/vector/k.dat)

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <sys/stat.h>   // mkdir в Linux

using namespace std;

long double **generate_matrix(int size){
	long double **matrix = new long double *[size];
	for(int i = 0; i < size; i++){
		matrix[i] = new long double [size];
	}
	srand(1);   // постоянное начальное значение: данные каждый раз одинаковые

	for (int i = 0; i < size; i++) {
		for(int j = i; j < size; j++){
			double random = ((double) rand() / RAND_MAX);
			random = round(random * 1e6) / 1e6;   // 6 знаков после запятой: в файл попадает точно это число
			if(i != j){
				matrix[i][j] = -random;
				matrix[j][i] = -random;
			} else {
				matrix[i][j] = (random + 0.5) * 10000;
			}
		}
	}
	return matrix;
}

long double *generate_vector(long double **matrix, int size){
	long double *vector = new long double [size];

	for(int i = 0; i < size; i++){
		long double sum = 0;
		for(int j = 0; j < size; j++){
			sum += matrix[i][j];
		}
		vector[i] = sum;
	}
	return vector;
}

// Проверка диагонального преобладания: a_ii > сумма |a_ij| (j != i) в каждой строке.
// Симметричная матрица с таким свойством положительно определена.
bool is_diagonally_dominant(long double **matrix, int size){
	for(int i = 0; i < size; i++){
		long double sum = 0;
		for(int j = 0; j < size; j++){
			if(j != i){
				sum += fabsl(matrix[i][j]);
			}
		}
		if(matrix[i][i] <= sum){
			return false;
		}
	}
	return true;
}

void out_matrix(string file_path, string filename, long double **matrix, int size){
	ofstream fout;

	fout.open(file_path + filename);
	fout.precision(10);   // по умолчанию было бы 6 значащих цифр

	for (int i = 0; i < size; i++) {
		for(int j = 0; j < size; j++){
			fout << matrix[i][j] << " ";
		}
	}

	fout.close();
}

void out_vector(string file_path, string filename, long double *vector, int size){
	ofstream fout;

	fout.open(file_path + filename);
	fout.precision(17);

	for (int i = 0; i < size; i++) {
		fout << vector[i] << " ";
	}

	fout.close();
}

void division_matrix(string file_path, long double **matrix, int matrix_size, int division_number){
	ofstream fout;
	int div = matrix_size / division_number;

	for(int k = 0; k < division_number; k++){
		fout.open(file_path + to_string(k) + ".dat");
		fout.precision(10);
		for (int i = 0; i < div; i++) {
			for(int j = 0; j < matrix_size; j++){
				fout << matrix[i + div * k][j] << " ";
			}
		}
		fout.close();
	}
}

void division_vector(string file_path, long double *vector, int vector_size, int division_number){
	ofstream fout;
	int div = vector_size / division_number;
	for(int k = 0; k < division_number; k++){
		fout.open(file_path + to_string(k) + ".dat");
		fout.precision(17);
		for (int i = 0; i < div; i++) {
			fout << vector[i + div * k] << " ";
		}
		fout.close();
	}
}

void print_vector(long double *vector, int size){
	for(int i = 0; i < size; i++){
		cout << vector[i] << " ";
	}
	cout << endl;
}

void print(long double **matrix, long double *vector, int size){
	cout << "--------------matrix--------------" << endl;
	for(int i = 0; i < size; i++){
		print_vector(matrix[i], size);
	}
	cout << "--------------vector--------------" << endl;
	print_vector(vector, size);
}

int divide(string filepath, long double **matrix, long double *vector, int size, int dividers_number){
	if(size % dividers_number != 0){
		return -1;
	}

	string dir = filepath + to_string(size) + "_" + to_string(dividers_number);
	mkdir(dir.c_str(), 0755);
	string dir_matrix = dir + "/matrix/";
	string dir_vector = dir + "/vector/";
	mkdir(dir_matrix.c_str(), 0755);
	mkdir(dir_vector.c_str(), 0755);

	division_vector(dir_vector, vector, size, dividers_number);
	division_matrix(dir_matrix, matrix, size, dividers_number);
	return 0;
}

int main(int argc, char** argv){
	if(argc < 2){
		cout << "usage: ./bin/creator n [p]" << endl;
		return 1;
	}
	int size = atoi(argv[1]);
	int dividers_number = 1;
	if(argc > 2){
		dividers_number = atoi(argv[2]);
	}

	long double **matrix;
	long double *vector;

	string filepath = "data/";
	mkdir("data", 0755);
	string filename_matrix = "m_" + to_string(size) + ".dat";   // имена, которые ищет reader.h
	string filename_vector = "v_" + to_string(size) + ".dat";

	//generate
	matrix = generate_matrix(size);
	vector = generate_vector(matrix, size);

	if(is_diagonally_dominant(matrix, size)){
		cout << "Matrix " << size << "x" << size << " is diagonally dominant" << endl;
	} else {
		// при n = 16384 это нормально: проверка достаточная, но не необходимая,
		// матрица всё равно положительно определена (проверено отдельно)
		cout << "Matrix " << size << "x" << size << " is not diagonally dominant" << endl;
	}

	//write to file
	out_matrix(filepath, filename_matrix, matrix, size);
	out_vector(filepath, filename_vector, vector, size);
	cout << "Written: " << filepath + filename_matrix << ", " << filepath + filename_vector << endl;

	//divide to directions (только если задано p > 1)
	if(dividers_number > 1){
		if(divide(filepath, matrix, vector, size, dividers_number) == -1){
			cout << "can't split! size(" << size << ") % dividers_number(" << dividers_number 
				<< ") = " << size % dividers_number << endl;
			return -2;
		}
	}
	
	//print to console (только маленькие матрицы)
	if(size <= 12){
		cout.precision(10);
		print(matrix, vector, size);
	}
	
	for(int i = 0; i < size; i++) {
		delete[] matrix[i];
	}
	delete[] vector;
	delete[] matrix;

	return 0;
}
