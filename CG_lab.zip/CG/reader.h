// Чтение вектора b и матрицы A из файлов data/v_<n>.dat и data/m_<n>.dat

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>

inline double* read_vector(int n, char* filepath)
{
    double* b = static_cast<double *>(malloc(n * sizeof(double)));
    char filename[300];
    sprintf(filename, "%s/v_%d.dat", filepath, n);   // имя файла для любого n
    std::ifstream f;
    f.open(filename);

    if (!f.is_open())
    {
        printf("vector file %s not found.\n", filename);
        return NULL;
    }

    for (int i = 0; i < n; ++i)
    {
        f >> b[i];
    }

    f.close();

    return b;
}

inline double** read_matrix(int n, char* filepath)
{
    double** a = static_cast<double **>(malloc(n * sizeof(double *)));
    for (int i = 0; i < n; ++i)
    {
        a[i] = static_cast<double *>(malloc(n * sizeof(double)));
    }
    char filename[300];
    sprintf(filename, "%s/m_%d.dat", filepath, n);   // имя файла для любого n
    std::ifstream f;
    f.open(filename);

    if (!f.is_open())
    {
        printf("matrix file %s not found.\n", filename);
        return NULL;
    }

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            f >> a[i][j];
        }
    }

    f.close();

    return a;
}
