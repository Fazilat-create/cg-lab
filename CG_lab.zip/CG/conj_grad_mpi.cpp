// MPI-версия conj_grad.cpp: тот же метод сопряжённых градиентов,
// матрица распределена между процессами по строкам.
// Компиляция: mpic++ -O2 -DSIZE=12 conj_grad_mpi.cpp -o bin/conj_grad_mpi_12
// Запуск:     mpirun --allow-run-as-root --oversubscribe -np 4 ./bin/conj_grad_mpi_12 ./data

#include <mpi.h>
#include <cstdio>
#include <fstream>
#include <cmath>
#include <iostream>
#include <string.h>
#include <stdlib.h>

#include "reader.h"

#ifndef SIZE
#define SIZE 1024
#endif

double dot_product(double* b1, double* b2, int n);

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv);

    int rank, nproc;   // номер процесса и число процессов
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nproc);

    if (argc < 2 || SIZE % nproc != 0)
    {
        if (rank == 0) printf("usage: %s data_dir (SIZE must be divisible by number of processes)\n", argv[0]);
        MPI_Finalize();
        return 1;
    }
    char filepath[256];
    strcpy(filepath, argv[1]);

    int n_loc = SIZE / nproc;   // число строк у каждого процесса
    int first = rank * n_loc;   // номер первой строки этого процесса

    FILE *time;
    char file_time[40];

    double alpha, beta, d1, d2, diff;

    // 1) Процесс 0 читает всю матрицу и вектор b
    double** a = NULL;
    double* b = NULL;
    if (rank == 0)
    {
        printf("Matrix size: %d*%d, processes: %d\n", SIZE, SIZE, nproc);
        a = read_matrix(SIZE, filepath);
        b = read_vector(SIZE, filepath);
        if (a == NULL || b == NULL)
        {
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    // 2) Вектор b целиком получает каждый процесс
    if (rank != 0)
    {
        b = static_cast<double*>(malloc(SIZE * sizeof(double)));
    }
    MPI_Bcast(b, SIZE, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    // 3) Строки матрицы: a_loc[i] - это строка номер first + i
    double** a_loc = static_cast<double**>(malloc(n_loc * sizeof(double*)));
    for (int i = 0; i < n_loc; ++i)
    {
        a_loc[i] = static_cast<double*>(malloc(SIZE * sizeof(double)));
    }
    if (rank == 0)
    {
        for (int i = 0; i < n_loc; ++i)        // свои строки процесс 0 просто копирует
        {
            memcpy(a_loc[i], a[i], SIZE * sizeof(double));
        }
        for (int p = 1; p < nproc; ++p)        // остальным отправляет по одной строке
        {
            for (int i = 0; i < n_loc; ++i)
            {
                MPI_Send(a[p * n_loc + i], SIZE, MPI_DOUBLE, p, 0, MPI_COMM_WORLD);
            }
        }
        for (int i = 0; i < SIZE; ++i)         // вся матрица больше не нужна
        {
            free(a[i]);
        }
        free(a);
    }
    else
    {
        for (int i = 0; i < n_loc; ++i)
        {
            MPI_Recv(a_loc[i], SIZE, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
    }

    // Векторы: x, x_n, r, r_n, h_n, tmp - только свои n_loc элементов;
    // h и x_full - полные (SIZE элементов): h нужен для умножения A*h,
    // x_full - для начального r0 = b - A*x0 и для сбора ответа.
    double* x = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* x_n = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* r = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* r_n = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* h_n = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* tmp = static_cast<double*>(malloc(n_loc * sizeof(double)));
    double* h = static_cast<double*>(malloc(SIZE * sizeof(double)));
    double* x_full = static_cast<double*>(malloc(SIZE * sizeof(double)));

    double d_loc;      // скалярное произведение по своим элементам
    double norm_loc;   // max|x_n - x| по своим элементам

    // ---- Начало замера ----
    MPI_Barrier(MPI_COMM_WORLD);
    double t_start = MPI_Wtime();

    // 1. Set x0
    for (int i = 0; i < n_loc; ++i)
    {
        x[i] = b[first + i] / a_loc[i][first + i];
    }
    MPI_Allgather(x, n_loc, MPI_DOUBLE, x_full, n_loc, MPI_DOUBLE, MPI_COMM_WORLD);

    // 2. Calculate residual vector r0 = b - A * x0
    for (int i = 0; i < n_loc; ++i)
    {
        tmp[i] = 0.0;
        for (int j = 0; j < SIZE; ++j)
        {
            tmp[i] += a_loc[i][j] * x_full[j];
        }
        r[i] = b[first + i] - tmp[i];
    }

    // 3. Calculate direction vector h0 = r0
    MPI_Allgather(r, n_loc, MPI_DOUBLE, h, n_loc, MPI_DOUBLE, MPI_COMM_WORLD);

    double norm;
    int it = 0;
    do
    {
        it++;

        //1 Calculate alpha
        d_loc = dot_product(r, r, n_loc);
        MPI_Allreduce(&d_loc, &d1, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

        for (int i = 0; i < n_loc; ++i)
        {
            tmp[i] = 0.0;
            for (int j = 0; j < SIZE; ++j)
            {
                tmp[i] += a_loc[i][j] * h[j];
            }
        }

        d_loc = dot_product(tmp, &h[first], n_loc);   // &h[first] - своя часть h
        MPI_Allreduce(&d_loc, &d2, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
        alpha = d1 / d2;

        //2 Calculate r_n
        for (int i = 0; i < n_loc; ++i)
        {
            r_n[i] = r[i] - alpha * tmp[i];
        }

        //3 Calculate beta
        d_loc = dot_product(r_n, r_n, n_loc);
        MPI_Allreduce(&d_loc, &d2, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
        beta = d2 / d1;

        //4 Calculate h_n and x_n
        for (int i = 0; i < n_loc; ++i)
        {
            h_n[i] = r_n[i] + beta * h[first + i];
            x_n[i] = x[i] + alpha * h[first + i];
        }

        norm_loc = fabs(x_n[0] - x[0]);
        for (int i = 0; i < n_loc; ++i)
        {
            diff = fabs(x_n[i] - x[i]);
            if (diff > norm_loc)
            {
                norm_loc = diff;
            }
            x[i] = x_n[i];
            r[i] = r_n[i];
        }
        MPI_Allreduce(&norm_loc, &norm, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);

        // h = h_n: собрать новый полный вектор h у всех процессов
        MPI_Allgather(h_n, n_loc, MPI_DOUBLE, h, n_loc, MPI_DOUBLE, MPI_COMM_WORLD);
    } while (norm > 1e-8 && it < 10000);

    double elapsed = MPI_Wtime() - t_start;   // время этого процесса
    // ---- Конец замера ----

    double max_time;   // время самого медленного процесса
    MPI_Reduce(&elapsed, &max_time, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    // Собрать полное решение на процессе 0
    MPI_Gather(x, n_loc, MPI_DOUBLE, x_full, n_loc, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        sprintf(file_time, "./out/time_%d.dat", SIZE);
        if ((time = fopen(file_time, "a")) == NULL) {
            printf("Error at opening of the file.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        fprintf(time, "%d\t%.12le\t%d\t%.12le\n", nproc, max_time, it, norm);   // 1-й столбец - число процессов
        fclose(time);

        printf("Number of iterations(K): %d\n", it);
        printf("Total time: %10.8f s\n", max_time);

        // Проверка: точное решение для данных creator - все единицы
        double err = 0.0;
        for (int i = 0; i < SIZE; ++i)
        {
            if (fabs(x_full[i] - 1.0) > err)
            {
                err = fabs(x_full[i] - 1.0);
            }
        }
        printf("max|x - 1|: %.3e\n", err);
        if (SIZE <= 12)
        {
            printf("x =");
            for (int i = 0; i < SIZE; ++i)
            {
                printf(" %.10f", x_full[i]);
            }
            printf("\n");
        }
    }

    for (int i = 0; i < n_loc; ++i)
    {
        free(a_loc[i]);
    }
    free(a_loc);
    free(b);
    free(x);
    free(x_n);
    free(r);
    free(r_n);
    free(h_n);
    free(tmp);
    free(h);
    free(x_full);

    MPI_Finalize();
    return 0;
}

double dot_product(double* b1, double* b2, int n)
{
    double res = 0.0;
    for (int i = 0; i < n; ++i)
    {
        res += b1[i] * b2[i];
    }
    return res;
}
